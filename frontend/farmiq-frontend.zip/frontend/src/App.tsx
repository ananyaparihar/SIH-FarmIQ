import { useEffect, useState } from "react";
import UploadPanel from "./components/UploadPanel";
import ResultCard from "./components/ResultCard";
import { translations, type Lang } from "./i18n";
import { predictProduce, type PredictResponse } from "./lib/api";

export default function App() {
  const [lang, setLang] = useState<Lang>("en");
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [result, setResult] = useState<PredictResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const t = translations[lang];

  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
    };
  }, [previewUrl]);

  function handleFileSelected(selected: File) {
    if (!selected.type.startsWith("image/")) {
      setError(t.errorBadFile);
      return;
    }
    setError(null);
    setResult(null);
    setFile(selected);
    setPreviewUrl(URL.createObjectURL(selected));
  }

  async function handleInspect() {
    if (!file) return;
    setIsLoading(true);
    setError(null);
    try {
      const response = await predictProduce(file);
      setResult(response);
    } catch {
      setError(t.errorGeneric);
    } finally {
      setIsLoading(false);
    }
  }

  function handleReset() {
    setFile(null);
    setPreviewUrl(null);
    setResult(null);
    setError(null);
  }

  return (
    <div className="mx-auto min-h-screen max-w-md px-6 py-10 sm:py-16">
      <header className="mb-10 flex items-baseline justify-between">
        <div>
          <h1 className="font-display text-xl font-semibold tracking-tight">
            {t.appName}
          </h1>
          <p className="font-sans text-xs text-charcoal/60">{t.tagline}</p>
        </div>
        <button
          type="button"
          onClick={() => setLang(lang === "en" ? "hi" : "en")}
          className="font-sans text-sm underline decoration-line underline-offset-4 hover:decoration-ink"
        >
          {t.langToggle}
        </button>
      </header>

      <main>
        <h2 className="mb-2 font-display text-2xl leading-snug">{t.heroTitle}</h2>
        <p className="mb-8 font-sans text-sm leading-relaxed text-charcoal/70">
          {t.heroBody}
        </p>

        <UploadPanel
          lang={lang}
          previewUrl={previewUrl}
          onFileSelected={handleFileSelected}
          error={error}
        />

        {file && !result && (
          <button
            type="button"
            onClick={handleInspect}
            disabled={isLoading}
            className="mt-4 w-full rounded-slip bg-ink py-3 font-sans text-sm font-medium text-paper transition-opacity disabled:opacity-50"
          >
            {isLoading ? t.inspecting : t.inspectButton}
          </button>
        )}

        {result && (
          <>
            <div className="mt-8">
              <ResultCard lang={lang} result={result} />
            </div>
            <button
              type="button"
              onClick={handleReset}
              className="mt-6 w-full rounded-slip border border-line py-3 font-sans text-sm font-medium text-ink"
            >
              {t.newInspection}
            </button>
          </>
        )}
      </main>
    </div>
  );
}
